# مشروع Flora Marketing Representative App — بناء APK عبر GitHub

هذا المشروع يغلّف ملف HTML داخل تطبيق Android بسيط باستخدام WebView. بيانات التطبيق المحلية (مثل IndexedDB وLocal Storage) تبقى على الجهاز، لذلك يجب استخدام النسخ الاحتياطي لنقل البيانات بين هاتفين.

## الملفات
- `app/src/main/assets/index.html`: نسخة HTML المرفقة بالتطبيق.
- `app/`: إعداد تطبيق Android.
- `.github/workflows/build-apk.yml`: يُنشأ هذا المسار في مستودع GitHub حسب الخطوات أدناه، وهو الذي يبني APK.

## خطوات GitHub من الهاتف
1. أنشئ مستودعاً باسم `FloraMarketingBuild` على GitHub.
2. من المستودع اختر **Add file → Create new file**.
3. في خانة اسم الملف اكتب بالضبط `.github/workflows/build-apk.yml`، ثم الصق محتوى ملف `build-apk.yml` المنفصل الذي تم توفيره لك، واحفظه بـ **Commit changes**.
4. بعد ذلك اختر **Add file → Upload files** وارفع `flora-apk-project.zip` إلى جذر المستودع، ثم اضغط **Commit changes**.
5. افتح تبويب **Actions**. انتظر انتهاء عملية `Build Flora APK` بنجاح.
6. افتح عملية البناء الناجحة، وانزل إلى **Artifacts**، ثم نزّل `Flora-Marketing-APK`.
7. فك ضغط ملف الـ Artifact، ثم ثبّت `app-debug.apk` على هاتف Android. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

## تنبيهات
- هذه نسخة Debug للتجربة، وليست نسخة منشورة على Google Play.
- جرّب أولاً على نسخة احتياطية من بياناتك؛ لا تحذف النسخة القديمة قبل التأكد من عمل الصور والاستيراد والتصدير.
- بناء APK لا يعني أن جميع ميزات HTML اختُبرت على الهاتف. اختبر الكاميرا ومعرض الصور والنسخ الاحتياطي ودمج النقاط عملياً.
