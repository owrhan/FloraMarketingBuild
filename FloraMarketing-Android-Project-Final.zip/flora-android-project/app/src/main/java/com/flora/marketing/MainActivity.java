package com.flora.marketing;

import android.app.Activity;
import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.content.Intent;
import android.provider.MediaStore;
import android.os.Environment;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 7124;
    private Uri cameraPhotoUri;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Keep Android's status bar (signal, clock, battery) and navigation bar visible.
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(0);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(10, 22, 40));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(10, 22, 40));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new PdfPrintBridge(), "AndroidPrintBridge");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    // For the dedicated camera input (capture="environment"), launch
                    // the device camera directly and return the full-size image URI.
                    if (params.isCaptureEnabled()) {
                        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (cameraIntent.resolveActivity(getPackageManager()) == null) {
                            filePathCallback = null;
                            Toast.makeText(MainActivity.this, "لا يوجد تطبيق كاميرا متاح", Toast.LENGTH_LONG).show();
                            return false;
                        }
                        File photoFile = createCameraImageFile();
                        cameraPhotoUri = FileProvider.getUriForFile(
                                MainActivity.this,
                                getPackageName() + ".fileprovider",
                                photoFile);
                        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri);
                        cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        startActivityForResult(cameraIntent, FILE_CHOOSER_REQUEST);
                    } else {
                        Intent intent = params.createIntent();
                        startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    }
                } catch (Exception e) {
                    if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    cameraPhotoUri = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح الكاميرا أو المعرض", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl("file:///android_asset/index.html");
    }

    private class PdfPrintBridge {
        @JavascriptInterface
        public void printPdf(String jobName) {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    if (printManager == null || webView == null) {
                        Toast.makeText(MainActivity.this, "تعذر فتح طباعة PDF", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String safeName = (jobName == null || jobName.trim().isEmpty()) ? "Flora Marketing Report" : jobName.trim();
                    PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(safeName);
                    PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(new PrintAttributes.Resolution("flora_pdf", "Flora PDF", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    printManager.print(safeName, adapter, attributes);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر إنشاء تقرير PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private File createCameraImageFile() throws IOException {
        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (dir == null) dir = getCacheDir();
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("تعذر إنشاء مجلد الصور");
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        return new File(dir, "FLORA_" + stamp + ".jpg");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results;
            if (cameraPhotoUri != null) {
                results = (resultCode == RESULT_OK) ? new Uri[]{cameraPhotoUri} : null;
                if (resultCode != RESULT_OK) {
                    try { new File(cameraPhotoUri.getPath()).delete(); } catch (Exception ignored) { }
                }
                cameraPhotoUri = null;
            } else {
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
